"""
English (en) translations for the Mental Outline VPN Platform.

This package supersedes locales/en.py (kept for reference).
Keys follow dot-notation: "section.key" (e.g. "welcome.greeting").

Phase 0.4: Added auth, language-selection, status, and role keys.
"""

TRANSLATIONS: dict[str, str] = {
    # ── Common ────────────────────────────────────────────────────────────
    "common.loading":           "⏳ Loading...",
    "common.error":             "⚠️ Something went wrong. Please try again.",
    "common.back":              "⬅️ Back",
    "common.cancel":            "❌ Cancel",
    "common.confirm":           "✅ Confirm",
    "common.yes":               "Yes",
    "common.no":                "No",
    "common.or":                "or",
    "common.done":              "✅ Done",
    "common.saved":             "✅ Saved!",
    "common.not_available":     "Not available yet.",

    # ── Welcome / onboarding ──────────────────────────────────────────────
    "welcome.greeting":         "👋 Welcome to Mental Outline VPN, {name}!",
    "welcome.greeting_back":    "👋 Welcome back, {name}!",
    "welcome.choose_lang":      "Please choose your language / ဘာသာစကားရွေးချယ်ပါ:",
    "welcome.lang_saved":       "✅ Language set to English.",
    "welcome.setup_complete":   "✅ All set! You can now use the bot.",

    # ── Language selection ────────────────────────────────────────────────
    "language.select_prompt":   "🌐 Choose your language:",
    "language.english":         "🇬🇧 English",
    "language.myanmar":         "🇲🇲 မြန်မာ",
    "language.changed":         "✅ Language changed to English.",
    "language.already_set":     "ℹ️ English is already your language.",

    # ── Auth / access ─────────────────────────────────────────────────────
    "auth.banned":              "🚫 Your account has been banned. Contact support.",
    "auth.suspended":           "⏸ Your account is temporarily suspended. Contact support.",
    "auth.inactive":            "Your account is inactive.",

    # ── Maintenance ───────────────────────────────────────────────────────
    "maintenance.message":      "🔧 The bot is currently under maintenance. Please try again later.",

    # ── Main menu ─────────────────────────────────────────────────────────
    "menu.packages":            "📦 Packages",
    "menu.my_keys":             "🔑 My VPN Keys",
    "menu.wallet":              "💰 Wallet",
    "menu.language":            "🌐 Language",
    "menu.help":                "ℹ️ Help",
    "menu.profile":             "👤 My Profile",
    "menu.admin":               "🛠 Admin Panel",
    "menu.settings":            "⚙️ Settings",

    # ── Profile ───────────────────────────────────────────────────────────
    "profile.title":            "👤 Your Profile",
    "profile.id":               "🆔 ID: {telegram_id}",
    "profile.name":             "👤 Name: {name}",
    "profile.username":         "🔗 Username: @{username}",
    "profile.role":             "🎭 Role: {role}",
    "profile.status":           "📊 Status: {status}",
    "profile.language":         "🌐 Language: {language}",
    "profile.member_since":     "📅 Member since: {date}",

    # ── Roles ─────────────────────────────────────────────────────────────
    "role.admin":               "Administrator",
    "role.customer":            "Customer",
    "role.reseller":            "Reseller",
    "role.affiliate":           "Affiliate",
    "role.moderator":           "Moderator",
    "role.vip":                 "VIP",

    # ── Statuses ──────────────────────────────────────────────────────────
    "status.active":            "✅ Active",
    "status.inactive":          "💤 Inactive",
    "status.suspended":         "⏸ Suspended",
    "status.banned":            "🚫 Banned",
    "status.pending":           "⏳ Pending",

    # ── Errors ────────────────────────────────────────────────────────────
    "error.unauthorized":       "⛔ You do not have permission to do that.",
    "error.admin_only":         "⛔ This command is for admins only.",
    "error.not_found":          "🔍 Not found.",
    "error.generic":            "⚠️ An unexpected error occurred. Our team has been notified.",
    "error.language_required":  "⚠️ Please select your language first.",

    # ── Placeholders (Phase 1+) ───────────────────────────────────────────
    "placeholder.coming_soon":  "🚧 Coming soon! Stay tuned.",

    "start.welcome_first": "👋 Welcome to Mental Outline VPN, {name}!",
    "language.select_bilingual": "Please choose your language / ဘာသာစကားရွေးချယ်ပါ:",
    "start.access_restricted": "🚫 Your account cannot access the bot right now.",
    "start.admin_placeholder": "🛠 Admin access confirmed.\n\nAdmin UI routing is ready. The full Admin Panel remains unchanged and will be connected through its router.",
    "start.customer_placeholder": "👋 Welcome to Mental Outline VPN!\n\n✅ Your customer account is ready.\nCustomer Main Menu will be added in Phase 1.2.",
    "start.future_role_placeholder": "👋 Welcome! Your role is {role}.\n\nThe dedicated interface for this role will be added in a later phase.",
    "start.error": "⚠️ Unable to start the bot right now. Please try again.",
    # ── Phase 1.2 Customer navigation ────────────────────────────────────
    'menu.customer_title': '🏠 Main Menu',
    'menu.customer_welcome': '👋 Welcome, {name}!\n\nChoose what you want to do:',
    'menu.buy_vpn': '🛒 Buy VPN',
    'menu.free_trial': '🎁 Free Trial',
    'menu.my_keys': '🔑 My Keys',
    'menu.wallet': '💰 Wallet',
    'menu.profile': '👤 Profile',
    'menu.support': '🎫 Support',
    'menu.input_hint': 'Choose an option…',
    'nav.home': '🏠 Main Menu',
    'nav.back': '⬅️ Back',
    'nav.invalid': '⚠️ This menu option is not available.',
    'nav.unknown': "I didn't recognize that message. Please choose an option from the menu below.",
    'page.buy_vpn.title': '🛒 Buy VPN',
    'page.buy_vpn.body': 'VPN package browsing will be connected in Phase 1.4. The navigation entry is ready.',
    'page.free_trial.title': '🎁 Free Trial',
    'page.free_trial.body': 'Free Trial access is visible now. Claim rules and eligibility will be implemented in the Growth System phase.',
    'page.my_keys.title': '🔑 My Keys',
    'page.my_keys.body': 'Your Free and Paid VPN keys will be shown here in Phase 1.5.',
    'page.wallet.title': '💰 Wallet',
    'page.wallet.body': 'Wallet details and transaction UI will be connected in Phase 1.3.',
    'page.profile.title': '👤 Profile',
    'page.profile.body': 'Your customer profile UI will be connected in Phase 1.3.',
    'page.support.title': '🎫 Support',
    'page.support.body': 'Support contact and help options will be connected in Phase 1.3.',


    # ── Phase 1.3 ──
    'common.not_set': 'Not set',
    'common.enabled': '✅ Enabled',
    'common.disabled': '❌ Disabled',
    'nav.previous': '⬅️ Previous',
    'nav.next': 'Next ➡️',
    'profile.phase13_title': '👤 User Profile',
    'profile.telegram_id': 'Telegram ID: {value}',
    'profile.username13': 'Username: {value}',
    'profile.first_name': 'First Name: {value}',
    'profile.last_name': 'Last Name: {value}',
    'profile.role13': 'Role: {value}',
    'profile.status13': 'Status: {value}',
    'profile.language13': 'Language: {value}',
    'profile.joined': 'Join Date: {value}',
    'profile.last_active13': 'Last Active: {value}',
    'profile.currency': 'Preferred Currency: {value}',
    'profile.notifications': 'Notifications: {value}',
    'profile.broadcasts': 'Broadcasts: {value}',
    'profile.language_button': '🌐 Language',
    'profile.notifications_button': '🔔 Notifications',
    'profile.notifications_state': 'Notifications: {value}',
    'wallet.title13': '💰 Wallet',
    'wallet.balance': 'Current Balance: {value}',
    'wallet.frozen': '🔒 Wallet is frozen.',
    'wallet.topup': '➕ Top Up',
    'wallet.transactions': '📜 Transaction History',
    'wallet.topup_placeholder': '➕ Top Up\n\nWallet top-up will be available in Phase 2. No balance has been changed.',
    'wallet.no_transactions': '📭 No transactions yet.',
    'wallet.transactions_title': '📜 Transaction History',
    'support.title13': '🎫 Support',
    'support.body': 'Need help?\nContact: {contact}',
    'support.unavailable': 'Support contact is not configured yet.',
    'support.hours': 'Support Hours: {value}',
    'support.email': 'Email: {value}',
    'support.contact_button': '💬 Contact Support',
    'support.faq_button': '❓ FAQ',
    'support.faq_body': '❓ FAQ\n\n• How to buy VPN? Use 🛒 Buy VPN.\n• Where are my keys? Use 🔑 My Keys.\n• How does Wallet work? Phase 2 will add top-up/payment.\n• Need help? Return to Support and contact us.',
}
