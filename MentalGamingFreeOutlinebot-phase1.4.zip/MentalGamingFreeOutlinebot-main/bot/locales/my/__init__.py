"""
Myanmar / Burmese (my) translations for the Mental Outline VPN Platform.

This package supersedes locales/my.py (kept for reference).
Keys must match those in locales/en/__init__.py exactly.
Missing keys fall back to English automatically via the Translator.

Phase 0.4: Added auth, language-selection, status, and role keys.
NOTE: Native-speaker review of Phase 0.4 additions is pending.
"""

TRANSLATIONS: dict[str, str] = {
    # ── Common ────────────────────────────────────────────────────────────
    "common.loading":           "⏳ ခဏစောင့်ပါ...",
    "common.error":             "⚠️ တစ်ခုခု မှားယွင်းသွားသည်။ ထပ်မံကြိုးစားပါ။",
    "common.back":              "⬅️ နောက်သို့",
    "common.cancel":            "❌ ပယ်ဖျက်ရန်",
    "common.confirm":           "✅ အတည်ပြုရန်",
    "common.yes":               "ဟုတ်သည်",
    "common.no":                "မဟုတ်ပါ",
    "common.or":                "သို့မဟုတ်",
    "common.done":              "✅ ပြီးပါပြီ",
    "common.saved":             "✅ သိမ်းဆည်းပြီး!",
    "common.not_available":     "မရရှိနိုင်သေးပါ။",

    # ── Welcome / onboarding ──────────────────────────────────────────────
    "welcome.greeting":         "👋 Mental Outline VPN မှ ကြိုဆိုပါသည်, {name}!",
    "welcome.greeting_back":    "👋 ပြန်လည်ကြိုဆိုပါသည်, {name}!",
    "welcome.choose_lang":      "ဘာသာစကားရွေးချယ်ပါ / Please choose your language:",
    "welcome.lang_saved":       "✅ မြန်မာဘာသာ သတ်မှတ်ပြီးပါပြီ။",
    "welcome.setup_complete":   "✅ အဆင်သင့်ဖြစ်ပါပြီ! bot ကိုအသုံးပြုနိုင်ပါပြီ။",

    # ── Language selection ────────────────────────────────────────────────
    "language.select_prompt":   "🌐 ဘာသာစကားရွေးချယ်ပါ:",
    "language.english":         "🇬🇧 English",
    "language.myanmar":         "🇲🇲 မြန်မာ",
    "language.changed":         "✅ မြန်မာဘာသာသို့ ပြောင်းလဲပြီးပါပြီ။",
    "language.already_set":     "ℹ️ မြန်မာဘာသာ သတ်မှတ်ပြီးဖြစ်သည်။",

    # ── Auth / access ─────────────────────────────────────────────────────
    "auth.banned":              "🚫 သင့်အကောင့်ကို ပိတ်ထားသည်။ support ကိုဆက်သွယ်ပါ။",
    "auth.suspended":           "⏸ သင့်အကောင့်ကို ယာယီရပ်ဆိုင်းထားသည်။ support ကိုဆက်သွယ်ပါ။",
    "auth.inactive":            "သင့်အကောင့် ပျက်ကွက်နေသည်။",

    # ── Maintenance ───────────────────────────────────────────────────────
    "maintenance.message":      "🔧 Bot ကို ယခုပြင်ဆင်နေသည်။ နောက်မှပြန်လာပါ။",

    # ── Main menu ─────────────────────────────────────────────────────────
    "menu.packages":            "📦 ပက်ကေ့ဂျ်များ",
    "menu.my_keys":             "🔑 ကျွန်ုပ်၏ VPN သော့များ",
    "menu.wallet":              "💰 ပိုက်ဆံအိတ်",
    "menu.language":            "🌐 ဘာသာစကား",
    "menu.help":                "ℹ️ အကူအညီ",
    "menu.profile":             "👤 ကျွန်ုပ်၏ ပရိုဖိုင်",
    "menu.admin":               "🛠 Admin Panel",
    "menu.settings":            "⚙️ ဆက်တင်များ",

    # ── Profile ───────────────────────────────────────────────────────────
    "profile.title":            "👤 ကျွန်ုပ်၏ ပရိုဖိုင်",
    "profile.id":               "🆔 ID: {telegram_id}",
    "profile.name":             "👤 နာမည်: {name}",
    "profile.username":         "🔗 Username: @{username}",
    "profile.role":             "🎭 အဆင့်: {role}",
    "profile.status":           "📊 အခြေအနေ: {status}",
    "profile.language":         "🌐 ဘာသာစကား: {language}",
    "profile.member_since":     "📅 စတင်ထည့်သွင်းသည့်ရက်: {date}",

    # ── Roles ─────────────────────────────────────────────────────────────
    "role.admin":               "စီမံခန့်ခွဲသူ",
    "role.customer":            "ဖောက်သည်",
    "role.reseller":            "ပြန်လည်ရောင်းချသူ",
    "role.affiliate":           "မိတ်ဖက်",
    "role.moderator":           "ကြီးကြပ်သူ",
    "role.vip":                 "VIP",

    # ── Statuses ──────────────────────────────────────────────────────────
    "status.active":            "✅ တက်ကြွသော",
    "status.inactive":          "💤 တက်ကြွမှုမရှိ",
    "status.suspended":         "⏸ ယာယီရပ်ဆိုင်း",
    "status.banned":            "🚫 တားမြစ်",
    "status.pending":           "⏳ စောင့်ဆိုင်းနေ",

    # ── Errors ────────────────────────────────────────────────────────────
    "error.unauthorized":       "⛔ ဤလုပ်ဆောင်ချက်ကို ခွင့်မပြုပါ။",
    "error.admin_only":         "⛔ ဤ command သည် admin များအတွက်သာဖြစ်သည်။",
    "error.not_found":          "🔍 မတွေ့ပါ။",
    "error.generic":            "⚠️ မမျှော်လင့်သောပြဿနာဖြစ်ပွားသည်။ ကျွန်ုပ်တို့ကိုအကြောင်းကြားထားပါသည်။",
    "error.language_required":  "⚠️ ဘာသာစကားကိုအရင်ရွေးချယ်ပါ။",

    # ── Placeholders (Phase 1+) ───────────────────────────────────────────
    "placeholder.coming_soon":  "🚧 မကြာမီလာမည်! ဆက်လက်စောင့်ကြည့်ပါ။",

    "start.welcome_first": "👋 Mental Outline VPN မှ ကြိုဆိုပါတယ်၊ {name}!",
    "language.select_bilingual": "ဘာသာစကားရွေးချယ်ပါ / Please choose your language:",
    "start.access_restricted": "🚫 လက်ရှိအချိန်တွင် သင့်အကောင့်ဖြင့် Bot ကို အသုံးပြုခွင့်မရှိပါ။",
    "start.admin_placeholder": "🛠 Admin အဖြစ် အတည်ပြုပြီးပါပြီ။\n\nAdmin UI routing အဆင်သင့်ဖြစ်ပါပြီ။ ရှိပြီးသား Admin Panel ကို router မှတစ်ဆင့် ဆက်သွယ်အသုံးပြုနိုင်ပါတယ်။",
    "start.customer_placeholder": "👋 Mental Outline VPN မှ ကြိုဆိုပါတယ်!\n\n✅ Customer account အဆင်သင့်ဖြစ်ပါပြီ။\nCustomer Main Menu ကို Phase 1.2 မှာ ထည့်ပါမယ်။",
    "start.future_role_placeholder": "👋 ကြိုဆိုပါတယ်။ သင့် Role သည် {role} ဖြစ်ပါတယ်။\n\nဒီ Role အတွက် သီးသန့် UI ကို နောက် Phase မှာ ထည့်ပါမယ်။",
    "start.error": "⚠️ Bot ကို စတင်၍မရသေးပါ။ ခဏအကြာ ထပ်မံကြိုးစားပါ။",
    # ── Phase 1.2 Customer navigation ────────────────────────────────────
    'menu.customer_title': '🏠 ပင်မ Menu',
    'menu.customer_welcome': '👋 ကြိုဆိုပါတယ်၊ {name}!\n\nလုပ်ဆောင်လိုတာကို ရွေးချယ်ပါ:',
    'menu.buy_vpn': '🛒 VPN ဝယ်မယ်',
    'menu.free_trial': '🎁 Free Trial',
    'menu.my_keys': '🔑 My Keys',
    'menu.wallet': '💰 Wallet',
    'menu.profile': '👤 Profile',
    'menu.support': '🎫 Support',
    'menu.input_hint': 'Menu တစ်ခုရွေးပါ…',
    'nav.home': '🏠 ပင်မ Menu',
    'nav.back': '⬅️ နောက်သို့',
    'nav.invalid': '⚠️ ဒီ Menu ကို အသုံးမပြုနိုင်သေးပါ။',
    'nav.unknown': 'ဒီစာကို နားမလည်ပါ။ အောက်က Menu ထဲက တစ်ခုကို ရွေးချယ်ပါ။',
    'page.buy_vpn.title': '🛒 VPN ဝယ်မယ်',
    'page.buy_vpn.body': 'VPN Package စာရင်းကို Phase 1.4 မှာ ချိတ်ဆက်ပါမယ်။ Navigation ကတော့ အဆင်သင့်ဖြစ်ပါပြီ။',
    'page.free_trial.title': '🎁 Free Trial',
    'page.free_trial.body': 'Free Trial Menu ကို အသုံးပြုနိုင်ပါပြီ။ Claim Rule နဲ့ Eligibility ကို Growth System Phase မှာ ထည့်ပါမယ်။',
    'page.my_keys.title': '🔑 My Keys',
    'page.my_keys.body': 'သင်ထုတ်ထားတဲ့ Free နဲ့ Paid VPN Key အားလုံးကို Phase 1.5 မှာ ဒီနေရာကနေ ကြည့်နိုင်ပါမယ်။',
    'page.wallet.title': '💰 Wallet',
    'page.wallet.body': 'Wallet Balance နဲ့ Transaction UI ကို Phase 1.3 မှာ ချိတ်ဆက်ပါမယ်။',
    'page.profile.title': '👤 Profile',
    'page.profile.body': 'Customer Profile UI ကို Phase 1.3 မှာ ချိတ်ဆက်ပါမယ်။',
    'page.support.title': '🎫 Support',
    'page.support.body': 'Support Contact နဲ့ Help Options ကို Phase 1.3 မှာ ချိတ်ဆက်ပါမယ်။',


    # ── Phase 1.3 ──
    'common.not_set': 'မသတ်မှတ်ရသေး',
    'common.enabled': '✅ ဖွင့်ထားသည်',
    'common.disabled': '❌ ပိတ်ထားသည်',
    'nav.previous': '⬅️ ရှေ့',
    'nav.next': 'နောက် ➡️',
    'profile.phase13_title': '👤 User Profile',
    'profile.telegram_id': 'Telegram ID: {value}',
    'profile.username13': 'Username: {value}',
    'profile.first_name': 'အမည်: {value}',
    'profile.last_name': 'နောက်ဆုံးအမည်: {value}',
    'profile.role13': 'Role: {value}',
    'profile.status13': 'အခြေအနေ: {value}',
    'profile.language13': 'ဘာသာစကား: {value}',
    'profile.joined': 'စတင်အသုံးပြုသည့်ရက်: {value}',
    'profile.last_active13': 'နောက်ဆုံးအသုံးပြုချိန်: {value}',
    'profile.currency': 'Currency: {value}',
    'profile.notifications': 'Notification: {value}',
    'profile.broadcasts': 'Broadcast: {value}',
    'profile.language_button': '🌐 ဘာသာစကား',
    'profile.notifications_button': '🔔 Notifications',
    'profile.notifications_state': 'Notifications: {value}',
    'wallet.title13': '💰 Wallet',
    'wallet.balance': 'လက်ကျန်ငွေ: {value}',
    'wallet.frozen': '🔒 Wallet ကို ယာယီပိတ်ထားသည်။',
    'wallet.topup': '➕ ငွေဖြည့်မယ်',
    'wallet.transactions': '📜 Transaction History',
    'wallet.topup_placeholder': '➕ ငွေဖြည့်မယ်\n\nWallet Top Up ကို Phase 2 မှာ ထည့်ပါမယ်။ ယခု Balance ကို မပြောင်းထားပါ။',
    'wallet.no_transactions': '📭 Transaction မရှိသေးပါ။',
    'wallet.transactions_title': '📜 Transaction History',
    'support.title13': '🎫 Support',
    'support.body': 'အကူအညီလိုပါသလား?\nဆက်သွယ်ရန်: {contact}',
    'support.unavailable': 'Support contact ကို မသတ်မှတ်ရသေးပါ။',
    'support.hours': 'Support အချိန်: {value}',
    'support.email': 'Email: {value}',
    'support.contact_button': '💬 Support ကိုဆက်သွယ်မယ်',
    'support.faq_button': '❓ FAQ',
    'support.faq_body': '❓ FAQ\n\n• VPN ဝယ်ရန် 🛒 Buy VPN ကိုသုံးပါ။\n• Key များကြည့်ရန် 🔑 My Keys ကိုသုံးပါ။\n• Wallet Top Up/Payment ကို Phase 2 မှာထည့်ပါမယ်။\n• အကူအညီလိုလျှင် Support ကိုပြန်ဝင်ပြီး ဆက်သွယ်ပါ။',    "package.catalog_title": "🛒 ရရှိနိုင်သော VPN Package များ\\nPackage တစ်ခုရွေးပါ:",
    "package.details_title": "📦 Package အသေးစိတ်",
    "package.name": "အမည်",
    "package.data": "ဒေတာ",
    "package.duration": "သက်တမ်း",
    "package.days": "ရက်",
    "package.devices": "စက်အရေအတွက်",
    "package.price": "ဈေးနှုန်း",
    "package.renewable": "သက်တမ်းတိုးနိုင်မှု",
    "package.server": "Server",
    "package.description": "ဖော်ပြချက်",
    "package.select": "✅ Package ရွေးမည်",
    "package.selected_title": "✅ Package ရွေးပြီးပါပြီ",
    "package.continue_payment": "💳 ငွေပေးချေမှုသို့ ဆက်ရန်",
    "package.payment_handoff": "ရွေးချယ်ထားသော Package ကို စစ်ဆေးပါ။ Phase 2 တွင် ငွေပေးချေမှုကို ဆက်လုပ်နိုင်ပါမည်။",
    "package.checkout_placeholder": "💳 ငွေပေးချေမှုစနစ်ကို Phase 2 တွင် ထည့်သွင်းပါမည်။ ယခုအချိန်တွင် ငွေဖြတ်ခြင်း သို့မဟုတ် Wallet Balance ပြောင်းခြင်း မရှိပါ။",
    "package.empty": "📭 လက်ရှိဝယ်ယူနိုင်သော VPN Package မရှိသေးပါ။\\nနောက်မှ ပြန်စစ်ကြည့်ပါ။",
    "package.unavailable": "⚠️ ဒီ Package ကို လက်ရှိမရနိုင်တော့ပါ။ Package စာရင်းကို Refresh လုပ်ပါ။",
    "package.refresh": "🔄 ပြန်လည်စစ်ဆေးရန်",
    "package.previous": "⬅️ ရှေ့စာမျက်နှာ",
    "package.next": "➡️ နောက်စာမျက်နှာ",
    "package.unlimited": "အကန့်အသတ်မရှိ",
    "package.server_auto": "အလိုအလျောက်ရွေးချယ်မည်",
    "package.server_premium": "Premium Server",
    "package.selection_expired": "⚠️ ရွေးချယ်ထားသော Package session သက်တမ်းကုန်သွားပါပြီ။ ပြန်ရွေးပါ။",
    "package.invalid_callback": "⚠️ Package လုပ်ဆောင်ချက် မမှန်ပါ။ Buy VPN ကို ပြန်ဖွင့်ပါ။",

}
