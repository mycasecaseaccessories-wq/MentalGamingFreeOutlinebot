"""Phase 1.4 customer package catalogue and Buy VPN handlers."""

from __future__ import annotations

import logging
import re
from decimal import Decimal

from telegram import Update
from telegram.ext import Application, CallbackQueryHandler, ContextTypes, MessageHandler, filters

from app.handlers.base import log_handler
from app.handlers.customer_navigation import _get_user, _is_customer_surface, _language
from app.keyboards.package_catalog import (
    build_empty_catalog_keyboard,
    build_package_details_keyboard,
    build_package_list_keyboard,
    build_package_selected_keyboard,
)
from app.models.package_catalog import PackageSelection, PackageSummary
from app.services.package_catalog_service import PackageCatalogService
from locales.translator import t

logger = logging.getLogger(__name__)
_SELECTION_KEY = "phase14_package_selection"


def _service(context: ContextTypes.DEFAULT_TYPE) -> PackageCatalogService | None:
    registry = context.bot_data.get("registry")
    return None if registry is None else registry.get_or_none(PackageCatalogService)


def _format_decimal(value: Decimal | None) -> str:
    if value is None:
        return "—"
    normalized = value.normalize()
    return format(normalized, "f").rstrip("0").rstrip(".") if "." in format(normalized, "f") else format(normalized, "f")


def _money(value: Decimal, currency: str) -> str:
    if value == value.to_integral_value():
        return f"{int(value):,} {currency}"
    return f"{value:,.2f} {currency}"


def _summary_line(pkg: PackageSummary, language: str) -> str:
    data = t("package.unlimited", language=language) if pkg.data_limit_gb is None else f"{_format_decimal(pkg.data_limit_gb)} GB"
    devices = t("package.unlimited", language=language) if pkg.device_limit is None else str(pkg.device_limit)
    badge = f" {pkg.badge}" if pkg.badge else ""
    return (
        f"📦 {pkg.name}{badge}\n"
        f"{t('package.data', language=language)}: {data}\n"
        f"{t('package.duration', language=language)}: {pkg.duration_days} {t('package.days', language=language)}\n"
        f"{t('package.devices', language=language)}: {devices}\n"
        f"{t('package.price', language=language)}: {_money(pkg.price, pkg.currency)}"
    )


def _server_label(pkg: PackageSummary, language: str) -> str:
    if pkg.server_policy == "country" and pkg.country:
        return pkg.country
    if pkg.server_policy == "premium":
        return t("package.server_premium", language=language)
    return t("package.server_auto", language=language)


async def _show_catalog(update: Update, context: ContextTypes.DEFAULT_TYPE, page: int = 1) -> None:
    user = _get_user(context)
    message = update.effective_message
    svc = _service(context)
    if not _is_customer_surface(user) or message is None:
        return
    lang = _language(user)
    if svc is None:
        await message.reply_text(t("common.error", language=lang))
        return
    result = await svc.get_available_packages(page=page)
    if not result.items:
        await message.reply_text(
            t("package.empty", language=lang),
            reply_markup=build_empty_catalog_keyboard(lang),
        )
        return
    text = t("package.catalog_title", language=lang) + "\n\n" + "\n\n".join(
        _summary_line(pkg, lang) for pkg in result.items
    )
    await message.reply_text(text, reply_markup=build_package_list_keyboard(result, lang))


async def _show_details(update: Update, context: ContextTypes.DEFAULT_TYPE, package_id: int) -> None:
    user = _get_user(context); message = update.effective_message; svc = _service(context)
    if not _is_customer_surface(user) or message is None:
        return
    lang = _language(user)
    pkg = None if svc is None else await svc.get_package_details(package_id)
    if pkg is None:
        await message.reply_text(t("package.unavailable", language=lang), reply_markup=build_empty_catalog_keyboard(lang))
        return
    description = pkg.description or t("common.not_set", language=lang)
    data = t("package.unlimited", language=lang) if pkg.data_limit_gb is None else f"{_format_decimal(pkg.data_limit_gb)} GB"
    devices = t("package.unlimited", language=lang) if pkg.device_limit is None else str(pkg.device_limit)
    renewable = t("common.yes" if pkg.renewable else "common.no", language=lang)
    text = "\n".join([
        t("package.details_title", language=lang), "",
        f"{t('package.name', language=lang)}: {pkg.name}",
        f"{t('package.data', language=lang)}: {data}",
        f"{t('package.duration', language=lang)}: {pkg.duration_days} {t('package.days', language=lang)}",
        f"{t('package.devices', language=lang)}: {devices}",
        f"{t('package.price', language=lang)}: {_money(pkg.price, pkg.currency)}",
        f"{t('package.renewable', language=lang)}: {renewable}",
        f"{t('package.server', language=lang)}: {_server_label(pkg, lang)}",
        f"{t('package.description', language=lang)}: {description}",
    ])
    await message.reply_text(text, reply_markup=build_package_details_keyboard(pkg.package_id, lang))


def _labels() -> set[str]:
    return {t("menu.buy_vpn", language=lang) for lang in ("en", "my")}


_LABELS = _labels()
_PATTERN = r"^(?:" + "|".join(re.escape(x) for x in _LABELS) + r")$"


@log_handler
async def buy_vpn_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _show_catalog(update, context, 1)


@log_handler
async def package_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query; user = _get_user(context)
    if q is None or not _is_customer_surface(user):
        return
    await q.answer()
    lang = _language(user)
    data = q.data or ""
    svc = _service(context)
    if svc is None:
        if q.message: await q.message.reply_text(t("common.error", language=lang))
        return

    try:
        if data.startswith("pkg:list:"):
            page = max(1, int(data.rsplit(":", 1)[1]))
            await _show_catalog(update, context, page)
            return

        if data.startswith("pkg:view:"):
            package_id = int(data.rsplit(":", 1)[1])
            if package_id <= 0: raise ValueError
            await _show_details(update, context, package_id)
            return

        if data.startswith("pkg:select:"):
            package_id = int(data.rsplit(":", 1)[1])
            if package_id <= 0: raise ValueError
            selection = await svc.prepare_purchase_handoff(user.telegram_id, package_id)
            if selection is None:
                if q.message: await q.message.reply_text(t("package.unavailable", language=lang))
                return
            context.user_data[_SELECTION_KEY] = selection
            if q.message:
                await q.message.reply_text(
                    "\n".join([
                        t("package.selected_title", language=lang), "",
                        f"{t('package.name', language=lang)}: {selection.package_name}",
                        f"{t('package.price', language=lang)}: {_money(selection.quoted_price, selection.currency)}",
                        "",
                        t("package.payment_handoff", language=lang),
                    ]),
                    reply_markup=build_package_selected_keyboard(selection.package_id, lang),
                )
            return

        if data == "pkg:checkout":
            selection = context.user_data.get(_SELECTION_KEY)
            if not isinstance(selection, PackageSelection):
                if q.message: await q.message.reply_text(t("package.selection_expired", language=lang))
                return
            current = await svc.get_package_details(selection.package_id)
            if current is None:
                context.user_data.pop(_SELECTION_KEY, None)
                if q.message: await q.message.reply_text(t("package.unavailable", language=lang))
                return
            if q.message:
                await q.message.reply_text(t("package.checkout_placeholder", language=lang))
            return
    except (TypeError, ValueError):
        logger.info("Malformed package callback: %r", data)
        if q.message:
            await q.message.reply_text(t("package.invalid_callback", language=lang))


def register(application: Application) -> None:
    application.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND & filters.Regex(_PATTERN), buy_vpn_message),
        group=8,
    )
    application.add_handler(
        CallbackQueryHandler(package_callback, pattern=r"^pkg:(?:list:\d+|view:\d+|select:\d+|checkout)$"),
        group=8,
    )
    logger.debug("Phase 1.4 package catalogue handlers registered")
